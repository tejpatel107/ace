const dropDownContainer = document.getElementById("dropdown-container");

export let isUserAtRootSelectOption = true; // [level = 0, listId = 0];
let currentLevel = 0;
let currentSelectedOption = undefined;
const currentSelectedOptions = [];

export const rootDropDown = document.getElementById("root-dropdown");
export let currentDropDown = rootDropDown;

dropDownContainer.addEventListener("change", (event) => {
  currentDropDown = event.target;

  currentLevel = Number(currentDropDown.dataset.level);
  currentSelectedOption = currentDropDown.options[currentDropDown.selectedIndex];
  
  getAllSelectedOptions();

  console.log(currentLevel, currentSelectedOption.dataset.listId);
  if (currentLevel !== 0 || Number(currentSelectedOption.dataset.listId) > 0) {
    isUserAtRootSelectOption = false;
    handleParentSelect();
  } else {
    isUserAtRootSelectOption = true;
  }

  console.log(isUserAtRootSelectOption);
});

export function addNewOptionToRootDropDown(listItem) {
  const option = document.createElement("option");
  option.value = listItem.dataset.listId;
  option.dataset.optionListId = listItem.dataset.listId;
  option.text = listItem.firstChild.firstChild.textContent;
  rootDropDown.append(option);
}

export function getParentHierarchy() {
  return currentSelectedOptions.map((element) => element.value);
}

function getAllSelectedOptions() {
  currentSelectedOptions = [...dropDownContainer.children].filter(element => element.options[element.selectedIndex]);
}

function handleParentSelect() {
  const selectedListId = currentSelectedOption.dataset.listId;

  const nextLevel = currentLevel + 1;

  // Remove all dropdowns deeper than the current one.
  removeDropdownsAfter(nextLevel);

  // If "Select" was chosen, there is nothing more to show.
  if (selectedListId === "0") {
    return;
  }

  // Find children of selected list item.
  const children = getChildrenOf(selectedListId);

  // If selected item has no children,
  // don't create another dropdown.
  if (children.length === 0) {
    return;
  }

  // Create the next dropdown.
  const nextDropdown = createDropdown(nextLevel);

  // Populate it with children.
  populateDropdown(nextDropdown, children);

  // Add it to the container.
  document
    .getElementById("parent-item-dropdown")
    .appendChild(nextDropdown);
}

function createDropdown(level) {
  const select = document.createElement("select");

  select.dataset.level = level;

  const defaultOption = document.createElement("option");

  defaultOption.value = "0";
  defaultOption.dataset.optionSubListId = "0";
  defaultOption.textContent = "Select";

  select.appendChild(defaultOption);

  select.addEventListener("change", handleParentSelect);

  return select;
}

function removeDropdownsAfter(level) {

  const dropdowns = Array.from(dropDownContainer.querySelectorAll("select"));

  for (const dropdown of dropdowns) {
    if (Number(dropdown.dataset.level) > level) {
      dropdown.remove();
    }
  }
}

function populateDropdown(dropdown, listItems) {
  // dropdown.innerHTML = "";

  // const defaultOption = document.createElement("option");

  // defaultOption.value = "0";
  // defaultOption.dataset.listId = "0";
  // defaultOption.textContent = "Select";

  // dropdown.appendChild(defaultOption);

  for (const listItem of listItems) {
    const option = document.createElement("option");

    option.value = listItem.dataset.listId;
    option.dataset.optionSubListId = listItem.dataset.listId;

    option.textContent =
      listItem.children[0].children[0].textContent;

    dropdown.appendChild(option);
  }
}

function getChildrenOf(parentId) {
  return Array.from(
    document.querySelectorAll("[data-option-list-id]")
  ).filter(item => {
    return item.dataset.parentId === String(parentId);
  });
}