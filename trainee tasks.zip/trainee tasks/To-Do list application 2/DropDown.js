export const dropDownContainer = document.getElementById("parent-item-dropdown");

dropDownContainer.addEventListener("change", (event) => {
  const select = event.target;

  if (!select.matches("select")) {
    return;
  }

  const level = Number(select.dataset.level);
  const parentId = select.value;

  console.log("Level:", level);
  console.log("Parent:", parentId);

  select.append(addNewSubListDropDown(parentId));


});

export function addNewSubListDropDown() {
    const subParentDropDown = document.createElement("select");
    subParentDropDown.add(new Option("Select", ""));
    return subParentDropDown;  
}
