export const dropDownContainer = document.getElementById("parent-item-dropdown");
export let dropDown = dropDownContainer.firstElementChild;
export let dropDownLevel = dropDown.dataset.level;
// const selectedOption = dropDown.options[dropDown.selectedIndex];
// export const parentOptionId = selectedOption.dataset.listId;

dropDownContainer.addEventListener("change", (event) => handleParentSelect(event));

function createDropdown(level) {
  const select = document.createElement("select");

  select.dataset.level = level;

  const defaultOption = document.createElement("option");

  defaultOption.value = "0";
  defaultOption.dataset.listId = "0";
  defaultOption.textContent = "Select";

  select.appendChild(defaultOption);

  select.addEventListener("change", handleParentSelect);

  return select;
}

function handleParentSelect(event) {
  const currentDropdown = event.currentTarget;

  const selectedOption =
    currentDropdown.options[currentDropdown.selectedIndex];

  const selectedListId =
    selectedOption.dataset.listId;

  const currentLevel =
    Number(currentDropdown.dataset.level);

  const nextLevel = currentLevel + 1;

  // Remove all dropdowns deeper than the current one.
  removeDropdownsAfter(nextLevel);

  // If "Select" was chosen, there is nothing more to show.
  if (selectedListId === "0") {
    return;
  }

  // Find children of selected list item.
  const children = getChildrenOf(selectedListId);

  // If selected item has no children,
  // don't create another dropdown.
  if (children.length === 0) {
    return;
  }

  // Create the next dropdown.
  const nextDropdown = createDropdown(nextLevel);

  // Populate it with children.
  populateDropdown(nextDropdown, children);

  // Add it to the container.
  document
    .getElementById("parent-item-dropdown")
    .appendChild(nextDropdown);
}

function getChildrenOf(parentId) {
  return Array.from(
    document.querySelectorAll("[data-list-id]")
  ).filter(item => {
    return item.dataset.parentId === String(parentId);
  });
}

function populateDropdown(dropdown, listItems) {
  dropdown.innerHTML = "";

  const defaultOption = document.createElement("option");

  defaultOption.value = "0";
  defaultOption.dataset.listId = "0";
  defaultOption.textContent = "Select";

  dropdown.appendChild(defaultOption);

  for (const listItem of listItems) {
    const option = document.createElement("option");

    option.value = listItem.dataset.listId;
    option.dataset.listId = listItem.dataset.listId;

    option.textContent =
      listItem.children[0].children[0].textContent;

    dropdown.appendChild(option);
  }
}

function removeDropdownsAfter(level) {
  const container =
    document.getElementById("parent-item-dropdown");

  const dropdowns =
    Array.from(container.querySelectorAll("select"));

  for (const dropdown of dropdowns) {
    if (Number(dropdown.dataset.level) > level) {
      dropdown.remove();
    }
  }
}

export function getSelectedParent() {
  const dropdowns =
    Array.from(dropDownContainer.querySelectorAll("select"));

  // Start from the deepest dropdown
  for (let i = dropdowns.length - 1; i >= 0; i--) {

    const dropdown = dropdowns[i];

    const selectedOption =
      dropdown.options[dropdown.selectedIndex];

    const listId =
      selectedOption.dataset.listId;

    if (listId && listId !== "0") {
      return {
        id: listId,
        level: Number(dropdown.dataset.level)
      };
    }
  }

  return null;
}

export function addListItemToDropdowns(listItem) {

    const level = Number(listItem.dataset.level);
    const parentId = listItem.dataset.parentId;
    const listId = listItem.dataset.listId;

    let targetDropdown;

    if (level === 1) {
        targetDropdown =
            dropDownContainer.querySelector(
                'select[data-level="1"]'
            );
    } else {
        targetDropdown =
            dropDownContainer.querySelector(
                `select[data-level="${level}"]`
            );
    }

    if (!targetDropdown) {
        return;
    }

    const option = document.createElement("option");

    option.value = listItem.dataset.listId;
    option.dataset.listId = listId;
    option.dataset.parentId = parentId;
    option.textContent =
        listItem.querySelector(".list-title").textContent;

    targetDropdown.append(option);
}
