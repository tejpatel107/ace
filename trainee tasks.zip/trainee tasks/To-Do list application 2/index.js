import { addNewOptionToRootDropDown, rootDropDown, currentDropDown, isUserAtRootSelectOption, getParentHierarchy} from "./DropDown.js";
import { createListItem, list } from "./ListItem.js";

const todoInput = document.getElementById("todo-input");

const newToDoAddButton = document.getElementById("add-button");

newToDoAddButton.addEventListener("click", () => {

  const inputValue = todoInput.value.trim();

  if (!inputValue) {
    return;
  }

  const listItem = createListItem(inputValue, null);

  if (isUserAtRootSelectOption) {
    listItem.dataset.level = 0;
    listItem.dataset.listId = rootDropDown.childElementCount;
    list.append(listItem);
    addNewOptionToRootDropDown(listItem);
  } else {
    listItem.dataset.level = currentLevel + 1;
    const parent = getParentElement();
    listItem.dataset.parentId = parent.dataset.subListId; 
    listItem.dataset.subListId = getParentElement().childElementCount + 1;
    
  }

  todoInput.value = "";

});

