// import { editingCard, clearListHierarchyBodyAndHideEditingCard, createParentListHierarchyOf } from "./EditingCard.js";

import { dropDownContainer } from "./DropDown.js";

const todoInput = document.getElementById("todo-input");
const lists = document.getElementById("list-container");
const newToDoAddButton = document.getElementById("add-button");


let [editMode, editingListItem] = [false, null];


newToDoAddButton.addEventListener("click", () => {

  // if (selectedParentId === 0) {
  //   listItem.dataset.listId = lists.childElementCount + 1;
  // }

  const listItem = createListItem(todoInput.value);
  addNewListItemToParentDropdown(listItem);
  listItem.classList.add("list-item-shadow");
  listItem.dataset.level = selectedParentId + 1;
  todoInput.value = "";
  lists.append(listItem);

});

function addNewListItemToParentDropdown(listItem) {

  const option = document.createElement("option");
  option.id = listItem.dataset.listId;
  option.dataset.level = listItem.dataset.level;
  option.value = listItem.children.item(0).children.item(0).textContent;
  option.textContent = option.value;

  const subDropDown = Array.from(dropDownContainer.children).find(element => element.dataset.level === String(Number(listItem.dataset.level) + 1));
  if (subDropDown) {
    subDropDown.appendChild(option);
  }
}

function deleteParentDropdown() {

}

function createListItem(inputValue) {
  const listItem = document.createElement("div");
  listItem.classList.add("list-item");

  const listTitleContainer = document.createElement("div");
  listTitleContainer.classList.add("list-title-container");

  const subListContainer = document.createElement("div");
  subListContainer.classList.add("sub-list-container");

  const title = document.createElement("label");
  title.textContent = inputValue;
  title.classList.add(".list-title");

  const editButton = document.createElement("button");
  editButton.type = "button";
  editButton.textContent = "edit";
  editButton.addEventListener("click", () =>
    handleSubListEditButtonClick(title),
  );

  const deleteButton = document.createElement("button");
  deleteButton.type = "button";
  deleteButton.textContent = "x";
  deleteButton.addEventListener("click", (event) => {
    event.currentTarget.closest(".list-item").remove();
    deleteParentDropdown
  });

  listTitleContainer.append(title, editButton, deleteButton);
  listItem.append(listTitleContainer, subListContainer);
  return listItem;
}

function createSubListItem() {
  return createListItem("");
}

// function handleAddSubListItem(subListContainer) {
//   const subListItem = createSubListItem();
//   subListItem.dataset.listId = subListContainer.childElementCount + 1;
//   subListItem.dataset.level =
//     Number(subListContainer.parentElement.dataset.level) + 1;
//   subListContainer.appendChild(subListItem);
// }

function handleSubListEditButtonClick(listItemTitle) {
  editMode = true;
  editingListItem = listItemTitle;
  newToDoAddButton.textContent = "Update";
  todoInput.value = listItemTitle.textContent;
  document.getElementById("list-heirarchy-content").innerHTML = "";
  editingCard.classList.remove("hidden");
  createParentListHierarchyOf(getParentsOfCurrentElement(editingListItem));
}



// function createParentListHierarchyOf(parents) {
//   const rootList = document.createElement("ul");

//   let currentList = rootList;

//   for (const parent of parents) {
//     const listItem = createListHierarchyItemFor(parent);

//     currentList.appendChild(listItem);

//     const childList = document.createElement("ul");
//     listItem.appendChild(childList);

//     currentList = childList;
//   }

//   document.getElementById("list-heirarchy-content").append(rootList);
// }

// function createListHierarchyItemFor(parent) {
//   const listItem = document.createElement("select");
//   listItem
//   listItem.textContent = parent.children[0].children[0].textContent;
//   return listItem;
// }

// function clearListHierarchyBodyAndHideEditingCard() {
//   document.getElementById("list-heirarchy-content").innerHTML = "";
//   editingCard.classList.add("hidden");
// }
