

function isDivisibleBy5(num) {
    return num % 5 === 0 ? true : 5;
}