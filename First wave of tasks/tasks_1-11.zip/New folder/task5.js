

function areElementsDivisibleBy2(arr) {
    return arr.every(num => num % 2 === 0);
}