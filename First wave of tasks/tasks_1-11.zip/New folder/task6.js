

function findUniqueElementFromArray(arr) {
    const set = new Set(arr);
    return [...set];
}