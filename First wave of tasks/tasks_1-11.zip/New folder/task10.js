

function calculateAgeFromDob(birthDate) {
    const today = new Date();
    const birthDateObj = new Date(birthDate);
    let age = today.getFullYear() - birthDateObj.getFullYear();
    const monthDifference = today.getMonth() - birthDateObj.getMonth();

    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDateObj.getDate())) {
        age--;
    }

    return age;

}


// todays date - September 1, 2026
// my dob - September 3, 2000

// age = 26
// monthDifference = 9 - 9 = 0