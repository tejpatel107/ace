

function filterTasksByDueDate(tasks, due_date) {
    return tasks.filter(task => task.due_date.valueOf() === due_date.valueOf());
}