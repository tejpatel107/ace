


function groupElemmentsByCriteria(arr, criteria) {

    group1 = arr.filter(element => criteria(element) );
    group2 = arr.filter(element => !criteria(element) );

    return [group1, group2];
}


criteria = function (value) {
    return value % 3 === 0;
};

 // [[3, 6], [1, 2, 4, 5]]

console.log(groupElemmentsByCriteria([1, 2, 3, 4, 5, 6], criteria));
