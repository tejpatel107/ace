

function sortArraybasedOnProperty(arr, property) {
    
    return arr.sort((a, b) => {

        let a = a[property];
        let b = b[property];

        if (typeof a === 'string' && typeof b === 'string') {
            return a.localeCompare(b);
        }

        return a - b;

    });


}