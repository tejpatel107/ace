

function isNumFloat(num) {

    return Number.isFinite(num) && !Number.isInteger(num);

}