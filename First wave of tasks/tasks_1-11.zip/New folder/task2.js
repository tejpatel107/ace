
function isValueString(value) {
    return typeof value === 'string';
}