
function validateFirstName() {
    const fname = document.getElementById("fname").value.trim();
    const errorElement = document.getElementById("fnameError");

    if (fname === "") {
        errorElement.textContent = "First name is required.";
    }
    else if (!/^[A-Za-z]+$/.test(fname)) {
        errorElement.textContent = "First name should not contain numbers or special characters.";
    } else {
        errorElement.textContent = "";
    }
}

function validateLastName() {
    const lname = document.getElementById("lname").value.trim();
    const errorElement = document.getElementById("lnameError");

    if (lname === "") {
        errorElement.textContent = "Last name is required.";
    } else if (!/^[A-Za-z]+$/.test(lname)) {
        errorElement.textContent = "Last name should not contain numbers or special characters.";
    } else {
        errorElement.textContent = ""; // Clear error if valid
    }
}

function validateEmail() {
    const email = document.getElementById("email").value.trim();
    const errorElement = document.getElementById("emailError");
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (email === "") {
        errorElement.textContent = "Email is required.";
    } else if (!emailPattern.test(email)) {
        errorElement.textContent = "Please enter a valid email address.";
    } else {
        errorElement.textContent = ""; // Clear error if valid
    }
}

function validatePassword() {
    const password = document.getElementById("password").value.trim();
    const errorElement = document.getElementById("passwordError");
    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;
    if (password === "") {
        errorElement.textContent = "Password is required.";
    } else if (password.length < 8 || !passwordPattern.test(password)) {
        errorElement.textContent = "Password should be of at least 8 characters and contain at least one lowercase letter, one uppercase letter, one digit, and one special character.";
    } else {
        errorElement.textContent = ""; // Clear error if valid
    }
}

