

const add = (a, b) => a + b;
const subtract = (a, b) => a - b;
const multiply = (a, b) => a * b;
const divide = (a, b) => b === 0 ? 'Error: Division by zero' : a / b;


function performOperation(operation) {
    
    const a = Number(document.getElementById('num1').value);
    const b = Number(document.getElementById('num2').value);

    const result = document.getElementById('result');

    switch (operation) {
        case 'add':
            result.value = add(a, b);
            break;
        case 'subtract':
            result.value = subtract(a, b);
            break;
        case 'multiply':
            result.value =  multiply(a, b);
            break;
        case 'divide':
            result.value = divide(a, b);
            break;
        default:
            result.value = 'Error: Invalid operation';
    }
}
